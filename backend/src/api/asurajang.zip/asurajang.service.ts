import { Injectable, Logger, HttpService, HttpException } from '@nestjs/common';
import { ViewMatchStatsDto } from './dto/view-match-stats.dto';
import { ViewMatchRecordDto } from './dto/view-match-record.dto';
import {
  CHAMP_NAMES, MMR_LABELS, REGION_LABELS, ITEM_NAMES, PLAY_MAP, TEAM_MAP
} from './constants/asurajang.constants';

@Injectable()
export class AsurajangService {
  private readonly BASE_URL = 'http://live.surajang.com:6557';
  private readonly logger = new Logger(AsurajangService.name);

  constructor(private readonly httpService: HttpService) {}

  /**
   * 솔로/트리오 통계 조회
   * @param userNetID
   * @param sessionSecret
   * @param dto
   */
  async viewMatchStats(userNetID: string, sessionSecret: string, dto: ViewMatchStatsDto): Promise<any> {
    try {
      const resp = await this.httpService.axiosRef.get(`${this.BASE_URL}/user/viewMatchStats`, {
        headers: {
          'Accept': '*/*',
          'Accept-Encoding': 'deflate, gzip',
          'Connection': 'Keep-Alive',
          'User-Agent': 'X-UnrealEngine-Agent',
        },
        params: {
          userNetID,
          sessionSecret,
          viewNickname: dto.viewNickname,
          region: dto.region || 'ES',
        },
        timeout: 5000,
      });
      return resp.data?.data || {};
    } catch (error) {
      this.logger.error('viewMatchStats API 오류', error);
      throw new HttpException('viewMatchStats 조회 실패', 500);
    }
  }

  /**
   * 최근 경기 상세 조회
   * @param userNetID
   * @param sessionSecret
   * @param dto
   */
  async viewMatchRecord(userNetID: string, sessionSecret: string, dto: ViewMatchRecordDto): Promise<any> {
    try {
      const resp = await this.httpService.axiosRef.get(`${this.BASE_URL}/user/viewMatchRecord`, {
        headers: {
          'Accept': '*/*',
          'Accept-Encoding': 'deflate, gzip',
          'Connection': 'Keep-Alive',
          'User-Agent': 'X-UnrealEngine-Agent',
        },
        params: {
          userNetID,
          sessionSecret,
          viewNickname: dto.viewNickname,
        },
        timeout: 5000,
      });
      return resp.data?.data || {};
    } catch (error) {
      this.logger.error('viewMatchRecord API 오류', error);
      throw new HttpException('viewMatchRecord 조회 실패', 500);
    }
  }
}
