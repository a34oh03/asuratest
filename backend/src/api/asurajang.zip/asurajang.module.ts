import { Module, HttpModule } from '@nestjs/common';
import { AsurajangService } from './asurajang.service';
import { AsurajangController } from './asurajang.controller';

@Module({
  imports: [HttpModule],
  controllers: [AsurajangController],
  providers: [AsurajangService],
})
export class AsurajangModule {}
