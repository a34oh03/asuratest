import {
  Controller, Get, Query, Body, Post, Logger, InternalServerErrorException
} from '@nestjs/common';
import { AsurajangService } from './asurajang.service';
import { ViewMatchStatsDto } from './dto/view-match-stats.dto';
import { ViewMatchRecordDto } from './dto/view-match-record.dto';

// 실제 서비스 환경에서는 아래 값을 환경변수로 분리해야 합니다.
const USER_NET_ID = '76561198112838034'; // TODO: 실서비스 시 환경변수로 분리
const SESSION_SECRET = '29ab989988bc858d5b709700fefd2e56'; // TODO: 실서비스 시 환경변수로 분리

@Controller('asurajang')
export class AsurajangController {
  private readonly logger = new Logger(AsurajangController.name);

  constructor(private readonly asurajangService: AsurajangService) {}

  /**
   * 솔로/트리오 통계 조회 API
   * GET /asurajang/match-stats?viewNickname=xxx&region=ES
   */
  @Get('match-stats')
  async getMatchStats(@Query() query: ViewMatchStatsDto) {
    try {
      return await this.asurajangService.viewMatchStats(USER_NET_ID, SESSION_SECRET, query);
    } catch (error) {
      this.logger.error('getMatchStats 오류', error);
      throw new InternalServerErrorException('통계 조회 실패');
    }
  }

  /**
   * 최근 경기 상세 조회 API
   * GET /asurajang/match-record?viewNickname=xxx
   */
  @Get('match-record')
  async getMatchRecord(@Query() query: ViewMatchRecordDto) {
    try {
      return await this.asurajangService.viewMatchRecord(USER_NET_ID, SESSION_SECRET, query);
    } catch (error) {
      this.logger.error('getMatchRecord 오류', error);
      throw new InternalServerErrorException('전적 조회 실패');
    }
  }
}
